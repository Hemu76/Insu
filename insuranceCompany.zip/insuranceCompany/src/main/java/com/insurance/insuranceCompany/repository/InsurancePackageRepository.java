package com.insurance.insuranceCompany.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.insuranceCompany.contract.InsurancePackageContract;
import com.insurance.insuranceCompany.model.InsurancePackage;
@Repository
public class InsurancePackageRepository {
	@Autowired
	private InsurancePackageContract insurancePackageDAO;

	
	public int addDisease(String name, String iCDCode, String description, String status, int inspid) {
		return insurancePackageDAO.addDisease(name, iCDCode, description, status, inspid);
	}

	
	public int deleteDisease(int did, int inspid) {
		return insurancePackageDAO.deleteDisease(did, inspid);

	}

	public String editDisease(String name, String iCDCode, String description, String status, String Id) {
		return insurancePackageDAO.editDisease(name, iCDCode, description, status, Integer.parseInt(Id));
	}
	
	public int deleteCategory(int did, int inspid) {
		return insurancePackageDAO.deleteCategory(did, inspid);
	}

	
	public int addCategory(String name, String title, String description, String string, int parseInt) {
		return insurancePackageDAO.addCategory(name, title, description, string, parseInt);
	}

	public String editCategory(String title, String description, String status) {
		return insurancePackageDAO.editCategory(title, description, status);
	}
	
	public int deletePackage(int did) {

		return insurancePackageDAO.deletePackage(did);
	}
	
	public String editPackage(String id, String title, String description, String status, String rangeStart,
			String rangeEnd, String ageLimitStrt, String ageLimitEnd) {
		return insurancePackageDAO.editPackage(id, title, description, status, rangeStart, rangeEnd, ageLimitStrt,
				ageLimitEnd);

	}
	public void addPackage(InsurancePackage insp) {
		insurancePackageDAO.addPackage(insp);
	}
}
